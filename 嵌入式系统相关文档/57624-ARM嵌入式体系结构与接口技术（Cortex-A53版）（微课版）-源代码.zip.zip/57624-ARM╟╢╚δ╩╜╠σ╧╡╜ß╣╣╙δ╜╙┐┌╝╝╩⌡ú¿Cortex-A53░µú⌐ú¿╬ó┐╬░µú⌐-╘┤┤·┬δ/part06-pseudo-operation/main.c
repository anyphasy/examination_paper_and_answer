unsigned long  ByteSwap (unsigned long val)
{
	int ret;
	asm volatile(
	"eor x3, %1, %1, ror #16\n\t"
	"bic x3, x3, #0x00ff0000\n\t"
	"mov %0, %1, ror #8\n\t"
	"eor %0, %0, x3, lsr #8"
	:"=r" (ret)
	:"0"(val)
	:"x3"
	);
	return ret;
}
int main(void)
{
	unsigned long test = 0x1234,result;
	result = ByteSwap(test);
	return 0;
}

