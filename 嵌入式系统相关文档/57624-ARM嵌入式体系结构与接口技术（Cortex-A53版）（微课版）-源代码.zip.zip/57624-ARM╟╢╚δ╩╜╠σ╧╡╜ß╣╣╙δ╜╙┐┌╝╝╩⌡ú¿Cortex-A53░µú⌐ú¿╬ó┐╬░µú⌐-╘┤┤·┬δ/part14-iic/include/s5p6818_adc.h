#ifndef __S5P6818_ADC_H__
#define __S5P6818_ADC_H__
/********************************
*ADC寄存器封装
*********************************/

#define 	ADCCON  		(*(volatile unsigned int *)0xC0053000)
#define 	ADCDAT  		(*(volatile unsigned int *)0xC0053004)
#define 	ADCINTENB  		(*(volatile unsigned int *)0xC0053008)
#define 	ADCINTCLR  		(*(volatile unsigned int *)0xC005300C)
#define 	PRESCALERCON  	(*(volatile unsigned int *)0xC0053010)
#define     IP_RESET_REGISTER1  (*(volatile unsigned int *)0xC0012004)

#endif
