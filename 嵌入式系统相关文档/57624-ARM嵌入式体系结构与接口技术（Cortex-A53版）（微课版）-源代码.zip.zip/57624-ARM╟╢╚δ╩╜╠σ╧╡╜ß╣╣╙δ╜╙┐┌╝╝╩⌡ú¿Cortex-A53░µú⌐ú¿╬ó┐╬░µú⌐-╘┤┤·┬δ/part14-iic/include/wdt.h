#ifndef __WDT_H__
#define __WDT_H__
#include "s5p6818_wdt.h"

void WDT_Init(void);

#endif
