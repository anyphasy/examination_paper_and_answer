#ifndef __DELAY_H__
#define __DELAY_H__

void delay_ms(unsigned int ms);

#endif
