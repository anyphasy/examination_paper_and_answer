#ifndef __I2C_H__
#define __I2C_H__

#define CTRL_REG1   0x2A
#define CTRL_REG2   0x2B
#define XYZ_DATA_CFG 0x0E

struct gray_t {
	short gray_x ;
	short gray_y ;
	short gray_z ;
};


void Read_Gray(struct gray_t *ret);

void iic_init(void);

#endif /* ___I2C_H__ */
