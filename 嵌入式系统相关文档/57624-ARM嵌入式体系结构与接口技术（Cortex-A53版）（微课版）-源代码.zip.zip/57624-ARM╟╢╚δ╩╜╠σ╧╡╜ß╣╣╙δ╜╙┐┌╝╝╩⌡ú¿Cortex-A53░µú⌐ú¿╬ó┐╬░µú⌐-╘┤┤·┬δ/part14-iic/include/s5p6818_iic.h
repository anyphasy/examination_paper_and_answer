#ifndef __S5P6818_IIC_H__
#define __S5P6818_IIC_H__
/************* IIC register**************/
typedef struct{
	unsigned int I2CCON;			// I2C-Bus control register
	unsigned int I2CSTAT;			// I2C-Bus control-status register
	unsigned int I2CADD;			// I2C-Bus address register
	unsigned int I2CDS;			// I2C-Bus transmit-receive data shift register
	unsigned int I2CLC;			// I2C-bus line control register
} i2c_t;
#define  IIC0     		(* (volatile i2c_t *)0xC00A4000)
#define  IIC1     		(* (volatile i2c_t *)0xC00A5000)
#define  IIC2     		(* (volatile i2c_t *)0xC00A6000)

#define  I2CVR0			(*(volatile unsigned int *)0xC00A4040)   // I2C-bus version register
#define  I2CVR1			(*(volatile unsigned int *)0xC00A5040)   // I2C-bus version register
#define  I2CVR2			(*(volatile unsigned int *)0xC00A6040)   // I2C-bus version register



// I2C通道0/1/2 时钟产生器使能寄存器
#define		I2CCLKENB0				(*(volatile unsigned int *)0xC00AE000)
#define		I2CCLKENB1				(*(volatile unsigned int *)0xC00AF000)
#define		I2CCLKENB2				(*(volatile unsigned int *)0xC00B0000)

#endif
