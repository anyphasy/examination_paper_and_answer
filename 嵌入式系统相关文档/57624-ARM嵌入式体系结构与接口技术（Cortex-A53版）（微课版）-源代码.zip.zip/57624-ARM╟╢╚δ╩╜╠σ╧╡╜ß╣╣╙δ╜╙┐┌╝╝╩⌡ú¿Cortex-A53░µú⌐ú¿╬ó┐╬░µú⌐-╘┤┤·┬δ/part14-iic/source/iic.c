#include "s5p6818_iic.h"
#include "s5p6818_gpio.h"
#include "s5p6818_ip_reset.h"
#include "delay.h"
#include "iic.h"
/**********************************************************************
 * 函数功能：I2C向特定地址写一个字节
 * 输入参数：
 * 		slave_addr： I2C从机地址
 * 			  addr： 芯片内部特定地址
 * 			  data：写入的数据
**********************************************************************/
void iic_write (unsigned char slave_addr, unsigned char addr, unsigned char data)
{
	/*对时钟源进行512倍预分频  打开IIC中断（每次完成一个字节的收发后中断标志位会自动置位）*/
	IIC2.I2CCON = IIC2.I2CCON | (1<<6) | (1<<5);

	/*设置IIC模式为主机发送模式  使能IIC发送和接收*/
	IIC2.I2CSTAT = 0xd0;
	/*将第一个字节的数据写入发送寄存器  即从机地址和读写位（MPU6050-I2C地址+写位0）*/
	IIC2.I2CDS = slave_addr<<1;
	/*设置IIC模式为主机发送模式  发送起始信号启用总线  使能IIC发送和接收*/
	IIC2.I2CSTAT = 0xf0;

	/*等待从机接受完一个字节后产生应答信号（应答后中断挂起位自动置位）*/
	while(!(IIC2.I2CCON & (1<<4)));

	/*将要发送的第二个字节数据（即MPU6050内部寄存器的地址）写入发送寄存器*/
	IIC2.I2CDS = addr;
	/*清除中断挂起标志位  开始下一个字节的发送*/
	IIC2.I2CCON = IIC2.I2CCON & (~(1<<4));
	/*等待从机接受完一个字节后产生应答信号（应答后中断挂起位自动置位）*/
	while(!(IIC2.I2CCON & (1<<4)));

	/*将要发送的第三个字节数据（即要写入到MPU6050内部指定的寄存器中的数据）写入发送寄存器*/
	IIC2.I2CDS = data;
	/*清除中断挂起标志位  开始下一个字节的发送*/
	IIC2.I2CCON = IIC2.I2CCON & (~(1<<4));
	/*等待从机接受完一个字节后产生应答信号（应答后中断挂起位自动置位）*/
	while(!(IIC2.I2CCON & (1<<4)));

	/*发送停止信号  结束本次通信*/
	IIC2.I2CSTAT = 0xD0;
	/*清除中断挂起标志位*/
	IIC2.I2CCON = IIC2.I2CCON & (~(1<<4));
	/*延时*/
	delay_ms(10);
}

unsigned char iic_read(unsigned char slave_addr, unsigned char addr)
{
	unsigned char data = 0;

	/*对时钟源进行512倍预分频  打开IIC中断（每次完成一个字节的收发后中断标志位会自动置位）*/
	IIC2.I2CCON = IIC2.I2CCON | (1<<6) | (1<<5);

	/*设置IIC模式为主机发送模式  使能IIC发送和接收*/
	IIC2.I2CSTAT = 0xd0;
	/*将第一个字节的数据写入发送寄存器  即从机地址和读写位（MPU6050-I2C地址+写位0）*/
	IIC2.I2CDS = slave_addr<<1;
	/*设置IIC模式为主机发送模式  发送起始信号启用总线  使能IIC发送和接收*/
	IIC2.I2CSTAT = 0xf0;
	/*等待从机接受完一个字节后产生应答信号（应答后中断挂起位自动置位）*/
	while(!(IIC2.I2CCON & (1<<4)));

	/*将要发送的第二个字节数据（即要读取的MPU6050内部寄存器的地址）写入发送寄存器*/
	IIC2.I2CDS = addr;
	/*清除中断挂起标志位  开始下一个字节的发送*/
	IIC2.I2CCON = IIC2.I2CCON & (~(1<<4));
	/*等待从机接受完一个字节后产生应答信号（应答后中断挂起位自动置位）*/
	while(!(IIC2.I2CCON & (1<<4)));

	/*清除中断挂起标志位  重新开始一次通信  改变数据传送方向*/
	IIC2.I2CCON = IIC2.I2CCON & (~(1<<4));

	/*将第一个字节的数据写入发送寄存器  即从机地址和读写位（MPU6050-I2C地址+读位1）*/
	IIC2.I2CDS = slave_addr << 1 | 0x01;
	/*设置IIC为主机接收模式  发送起始信号  使能IIC收发*/
	IIC2.I2CSTAT = 0xb0;
	/*等待从机接收到数据后应答*/
	while(!(IIC2.I2CCON & (1<<4)));


	/*禁止主机应答信号（即开启非应答  因为只接收一个字节）  清除中断标志位*/
	IIC2.I2CCON = IIC2.I2CCON & (~(1<<7))&(~(1<<4));
	/*等待接收从机发来的数据*/
	while(!(IIC2.I2CCON & (1<<4)));
	/*将从机发来的数据读取*/
	data = IIC2.I2CDS;

	/*直接发起停止信号结束本次通信*/
	IIC2.I2CSTAT = 0x90;
	/*清除中断挂起标志位*/
	IIC2.I2CCON = IIC2.I2CCON & (~(1<<4));
	/*延时等待停止信号稳定*/
	delay_ms(10);

	return data;
}
void Read_Gray(struct gray_t *ret)
{
	unsigned char buf[6] = {0};

	buf[0] = iic_read(0x1c, 0x1);
	buf[1] = iic_read(0x1c, 0x2);
	buf[2] = iic_read(0x1c, 0x3);
	buf[3] = iic_read(0x1c, 0x4);
	buf[4] = iic_read(0x1c, 0x5);
	buf[5] = iic_read(0x1c, 0x6);

	short temp;

	temp = ((short)((buf[0]<<8)|buf[1]));
	ret->gray_x = temp * 2.0 * 9800 / 8192 / 4; 
		
	temp = ((short)((buf[2]<<8)|buf[3]));
	ret->gray_y = temp * 2.0 * 9800 / 8192 / 4; 

	temp = ((short)((buf[4]<<8)|buf[5]));
	ret->gray_z = temp * 2.0 * 9800 / 8192 / 4; 
}

void iic_init(void)
{
  	IP_RESET_REGISTER0 = IP_RESET_REGISTER0 & (~(0x7 << 20));                                             
    IP_RESET_REGISTER0 = IP_RESET_REGISTER0 | (0x7 << 20);
	GPIOD.ALTFN0 = GPIOD.ALTFN0 & (~(0xF << 12));
	GPIOD.ALTFN0 = GPIOD.ALTFN0 | (0x5 << 12);

	IIC2.I2CCON = IIC2.I2CCON & (~(1 << 6));
	IIC2.I2CCON = IIC2.I2CCON & (~(0xF << 0));
	IIC2.I2CCON = IIC2.I2CCON | (124 << 0);
//	IIC2.I2CCON = IIC2.I2CCON | (0xF << 0);
//	IIC2.I2CADD = 0x1c;
	IIC2.I2CLC = 0x7;
	// mma845x_init
	iic_write(0x1c, CTRL_REG1, 0x01);    
	iic_write(0x1c, CTRL_REG2, 0x02);    
	iic_write(0x1c, XYZ_DATA_CFG, 0x10);

}

