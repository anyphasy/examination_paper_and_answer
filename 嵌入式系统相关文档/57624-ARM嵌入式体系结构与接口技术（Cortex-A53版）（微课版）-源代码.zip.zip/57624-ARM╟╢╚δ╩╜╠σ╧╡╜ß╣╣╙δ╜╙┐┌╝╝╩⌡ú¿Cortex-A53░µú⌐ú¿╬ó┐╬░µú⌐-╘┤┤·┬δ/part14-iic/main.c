#include "iic.h"
#include "common.h"
#include "delay.h"


int main()
{
	struct gray_t data;

	iic_init();
	while (1) {
		Read_Gray(&data);

		printf("gray_x = %d\n", data.gray_x);
		printf("gray_y = %d\n", data.gray_y);
		printf("gray_z = %d\n", data.gray_z);
		delay_ms(500);
	}
	return 0;
}
