#include "adc.h"
/*****************************
* 函数功能：延时函数
******************************/
void delay_ms(unsigned int ms)
{
		unsigned int i,j;
		for(i = 0; i < ms; i++)
			for(j = 0; j < 2000; j++);
}

int main()
{
		unsigned int value;
		hal_adc_init();
		while(1)
		{
			value = hal_adc_conversion();
			printf("adc value = %dmv\n", value);
			delay_ms(100);
		}
	return 0;
}
