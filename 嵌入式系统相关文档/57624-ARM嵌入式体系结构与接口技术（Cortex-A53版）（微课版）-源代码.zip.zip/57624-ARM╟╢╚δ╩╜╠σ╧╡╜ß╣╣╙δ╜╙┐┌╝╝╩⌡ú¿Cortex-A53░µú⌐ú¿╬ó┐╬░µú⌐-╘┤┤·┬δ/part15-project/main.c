#include "uart0.h"
#include "adc.h"
#include "key_interrupt.h"
#include "beep-pwm.h"
#include "led.h"
#include "ds18b20.h"
#include "pwm-timer.h"
#include "delay.h"

int main()
{
	int v;
	// 调用硬件初始化代码
	interrupt_gpio_init();
	interrupt_gicd_init();
	interrupt_gicc_init();
	hal_adc_init();
	hal_uart_init();
	hal_beep_init();
	hal_led_init();
	ds18b20_init();
	hal_timer_init();
	hal_timer_on();
	timer_gicd_init();
	timer_gicc_init();

	while(1)
	{
		v = hal_adc_conversion();
		if(v <= 2500) {
			led_status(RED,LED_ON);
			led_status(GREEN,LED_OFF);
			led_status(BLUE,LED_OFF);
		}
		else if(v > 2500 && v < 3000) {
			led_status(RED,LED_OFF);
			led_status(GREEN,LED_ON);
			led_status(BLUE,LED_OFF);
		}
		else if(v > 3000) {
			led_status(RED,LED_OFF);
			led_status(GREEN,LED_OFF);
			led_status(BLUE,LED_ON);
		}
	}
	return 0;
}

