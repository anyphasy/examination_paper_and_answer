/*
 * s5p6818-irq.c
 *

 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include "s5p6818-irq.h"
#include "uart0.h"
#include "adc.h"
#include "ds18b20.h"
#include "s5p6818_gpio.h"
#include "s5p6818_gic.h"
#include "s5p6818_pwm.h"
#include "beep-pwm.h"

static void s5p6818_irq_handler_func_gpioa(void * data)
{
}

static void s5p6818_irq_handler_func_gpiob(void * data)
{
}

static void s5p6818_irq_handler_func_gpioc(void * data)
{
}

static void s5p6818_irq_handler_func_gpiod(void * data)
{
}

static void s5p6818_irq_handler_func_gpioe(void * data)
{
}

static inline void s5p6818_gpio_alv_write_enable(void)
{
}

static inline void s5p6818_gpio_alv_write_disable(void)
{
}

static void s5p6818_irq_handler_func_gpioalv(void * data)
{

}

void el1_sync_invalid(void)
{
}

void el1_irq_invalid(void)
{
}

void el1_fiq_invalid(void)
{
}

void el1_error_invalid(void)
{
}

void el1_sync(void)
{
}
unsigned int sec = 0;
void el1_irq(void)
{
	unsigned int irq_num;
	short temp;
	int valtage;
	static int flag = 0;

	//获取中断号
	irq_num = GICC_IAR & 0x3FF;
	switch(irq_num){
		case 59:
			// 每隔1分钟打印一次温度和电压值
			sec++;
			valtage = hal_adc_conversion();
			temp = read_temp();
			if (sec%120 == 0) {
				printf("V = %d%", valtage / 33);	
				printf("    Temp = %d\n", temp);
			}
			if(flag == 1 && temp <= 30 && temp >= 20){
				flag = 0;
			}
			if (flag == 0) {
				if (sec%2 == 0 && (temp > 30 || temp < 20)) {
					hal_beep_on();
				} else if(sec%2 != 0 && (temp > 30 || temp < 20)) {
					hal_beep_off();
				} else if (temp <= 30 && temp >= 20) {	
					hal_beep_off();
				}
			}
			// 清除分配器层中断挂起标志位 GICD_ICPENDER1[27]
			GICD_ICPENDER.ICPENDER1 |= (1 << 27);
			// 清除PWM定时器层中断挂起标志位
			PWM.TINT_CSTAT |= (1 << 5);

		break;
		case 86:
			if((GPIOB.DET & (1 << 8)) == (1 << 8))
			{
				flag = 1;
				hal_beep_off();
				// 清除GPIO中断挂起标志位 DET[8]
				GPIOB.DET |= (1 << 8);
			}
			else if((GPIOB.DET & (1 << 16)) == (1 << 16))
			{
				// 清除GPIO中断挂起标志位 DET[16]
				GPIOB.DET |= (1 << 16);
			
			}
			// 清除分配器层中断挂起标志位 GICD_ICPENDER2[22]
			GICD_ICPENDER.ICPENDER2 |= (1 << 22);
			break;
		case 87:
			break;
		default:
			break;
	}
	// 清除中断号 
	GICC_EOIR = (GICC_EOIR & (~0x3FF)) | irq_num;
}

void el0_sync(void)
{
}

void el0_irq(void)
{
}

void el0_fiq_invalid(void)
{
}

void el0_error_invalid(void)
{
}

void el0_sync_compat(void)
{
}

void el0_irq_compat(void)
{
}

void el0_fiq_invalid_compat(void)
{
}

void el0_error_invalid_compat(void)
{
}
#define 	GPIOBDET			0xC001B014
/*
 * do_irq handles the Irq exception.
 */

void s5p6818_irq_enable(int no)
{
}

void s5p6818_irq_disable(int no)
{
}

void s5p6818_irq_set_type(int no, enum irq_type_t type)
{
}


