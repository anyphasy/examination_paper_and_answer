#include "pwm-timer.h"


void hal_timer_init(void)
{
		// 设置一级预分频值，设置PWM0通道，设置TCFG0[7:0]位，设置为249
		PWM.TCFG0 = PWM.TCFG0 & (~(0xFF << 0));
		PWM.TCFG0 = PWM.TCFG0 | (249 << 0);
		// 设置二级与分频值，设置TCFG1[3:0]位，设置为0100，进行16分频
		PWM.TCFG1 = PWM.TCFG1 & (~(0xF << 0));
		PWM.TCFG1 = PWM.TCFG1 | (0x4 << 0);
}

void hal_timer_on()
{
		// 设置PWM的最终周期，设置TCNTB2， 设置为10
		PWM.TCNTB0 = 18750;
		// 打开手动加载
		PWM.TCON = PWM.TCON | (0x1 << 1);
		// 关闭手动加载
		PWM.TCON = PWM.TCON & (~(0x1 << 1));
		// 打开自动加载
		PWM.TCON = PWM.TCON | (0x1 << 3);
		// 使能PWM定时器
		PWM.TCON = PWM.TCON | (0x1 << 0);
		// 使能PWM定时器中断
		PWM.TINT_CSTAT |= 1;

}
void hal_timer_off()
{
		// 关闭自动加载
		PWM.TCON = PWM.TCON & (~(0x1 << 3));
		// 关闭PWM定时器
		PWM.TCON = PWM.TCON & (~(0x1 << 0));
		// 禁止PWM定时器中断
		PWM.TINT_CSTAT &= ~1;
}
void timer_gicd_init()
{
	//1. GICD层中断使能寄存器 GICD_ISENABLER1[27]
	GICD_ISENABLER.ISENABLER1 |= (1 << 27);
	//2. 设置中断的优先等级 GICD_IPRIORITYR14[31:24]
	GICD_IPRIORITYR.IPRIORITYR14 &= (~(0xFF << 24));
	GICD_IPRIORITYR.IPRIORITYR14 |= (59 << 24);
	//3. 设置目标分配寄存器，分配给那个CPU
	//GICD_ITARGETSR14[31:24] = 0x1
	GICD_ITARGETSR.ITARGETSR14 &= (~(0xFF << 24));
	GICD_ITARGETSR.ITARGETSR14 |= (1 << 24);
	
	//4.设置GICD层全局使能  GICD_CTRL[0] = 0x1 
	GICD_CTRL |= 1;

}
void timer_gicc_init()
{
	//1. 设置中断优先级屏蔽寄存器 GICC_PMR[7:0]
	GICC_PMR |= 255;
	//2. 设置GICC层的中断使能位  GICC_CTRL[0]
	GICC_CTRL |= 1;
}


