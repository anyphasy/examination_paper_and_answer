#include "led.h"
#include "delay.h"
void hal_led_init(void)
{
	// RED
	GPIOA.ALTFN1 = GPIOA.ALTFN1 & (~(0x3 << 24));
	GPIOA.OUTENB = GPIOA.OUTENB | (1 << 28);
	
	// GREEN
	GPIOE.ALTFN0 = GPIOE.ALTFN0 & (~(0x3<< 26));
	GPIOE.OUTENB = GPIOE.OUTENB | (1 << 13);

	//BLUE
	GPIOB.ALTFN0 = (GPIOB.ALTFN0 & (~(0x3 << 24))) | (0x2 << 24);
	GPIOB.OUTENB |= (1 << 12);
}
void led_status(led_t leds, stu_t st)
{
	switch(leds){
	case RED:
		if (LED_ON == st)
			// 点亮
			GPIOA.OUT = GPIOA.OUT | (1 << 28);
		else
			// 熄灭
			GPIOA.OUT = GPIOA.OUT & (~(1 << 28));
		break;
	case GREEN:
		if (LED_ON == st)
			GPIOE.OUT = GPIOE.OUT | (1 << 13);
		else
			GPIOE.OUT = GPIOE.OUT & (~(1 << 13));
		break;
	case BLUE:
		if (LED_ON == st)
			GPIOB.OUT |= (1 << 12);
		else
			GPIOB.OUT &= (~(1 << 12));
		break;
	}
}
