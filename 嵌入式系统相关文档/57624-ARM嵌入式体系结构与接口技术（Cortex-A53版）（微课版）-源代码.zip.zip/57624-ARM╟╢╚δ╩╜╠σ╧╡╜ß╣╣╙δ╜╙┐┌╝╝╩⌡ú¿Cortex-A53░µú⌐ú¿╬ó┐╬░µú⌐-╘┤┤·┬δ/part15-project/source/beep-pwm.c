#include "beep-pwm.h"


void hal_beep_init(void)
{
	// 1. 设置GPIOC14引脚为PWM功能
	GPIOC.ALTFN0 = GPIOC.ALTFN0 & (~(0x3 << 28));
	GPIOC.ALTFN0 = GPIOC.ALTFN0 | (0x2 << 28);
	// 2. 设置一级预分频值，设置PWM2通道，设置TCFG0[15:8]位，设置为249
	PWM.TCFG0 = PWM.TCFG0 & (~(0xFF << 8));
	PWM.TCFG0 = PWM.TCFG0 | (249 << 8);
	// 3. 设置二级与分频值，设置TCFG1[11:8]位，设置为0100，进行16分频
	PWM.TCFG1 = PWM.TCFG1 & (~(0xF << 8));
	PWM.TCFG1 = PWM.TCFG1 | (0x4 << 8);
}

void hal_beep_on()
{
	// 设置PWM的最终周期，设置TCNTB2， 设置为10
	PWM.TCNTB2 = 10;
	// 设置PWM的占空比，设置为50%， 设置为5
	PWM.TCMPB2 = 5;
	// 打开手动加载
	PWM.TCON = PWM.TCON | (0x1 << 13);
	// 关闭手动加载
	PWM.TCON = PWM.TCON & (~(0x1 << 13));
	// 打开自动加载
	PWM.TCON = PWM.TCON | (0x1 << 15);
	// 打开翻转
	PWM.TCON = PWM.TCON | (0x1 << 14);
	// 使能PWM定时器
	PWM.TCON = PWM.TCON | (0x1 << 12);

}
void hal_beep_off()
{
	// 关闭自动加载
	PWM.TCON = PWM.TCON & (~(0x1 << 15));
	// 关闭PWM定时器
	PWM.TCON = PWM.TCON & (~(0x1 << 12));
}


