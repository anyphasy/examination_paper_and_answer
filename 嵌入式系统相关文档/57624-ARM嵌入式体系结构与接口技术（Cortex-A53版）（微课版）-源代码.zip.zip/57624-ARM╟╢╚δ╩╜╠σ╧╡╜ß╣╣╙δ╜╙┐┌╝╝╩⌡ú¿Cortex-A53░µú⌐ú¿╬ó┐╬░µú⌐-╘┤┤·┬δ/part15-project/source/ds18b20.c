#include "ds18b20.h"
/*  微妙级别的延时函数  */
void udelay(int usec)
{
	int i = 0, j = 0;
	for(i = 0; i < usec; i++) 
		for(j = 0; j < 2; j++);	
}

/*   设置ALIVEGPIO5引脚输出电平   */
void gpio_set_value(int value)
{
	ALIVE.ALIVEGPIOPADOUTENBSETREG = (1 << 5);
	if (value) {
		ALIVE.ALIVEGPIOPADOUTSETREG = (0x1 << 5);
	} else {
		ALIVE.ALIVEGPIOPADOUTRSTREG = (0x1 << 5);
	}
}

/*   获取ALIVEGPIO5引脚输入电平   */
int gpio_get_value(void)
{
	//ALIVE.ALIVEGPIOPADOUTENBSETREG = (~(1 << 5));
	ALIVE.ALIVEGPIOPADOUTENBRSTREG = (1 << 5);
	
	return ((ALIVE.ALIVEGPIOINPUTVALUE >> 5) & 0x01);
}

/*   ds18b20初始化的函数   */
void ds18b20_init(void)
{
	ALIVE.ALIVEPWRGATEREG = 0x1;
	
	gpio_set_value(0);
	udelay(495);
	gpio_set_value(1);
	udelay(60);
	gpio_get_value();
	udelay(240);
	gpio_set_value(1);
}

/*   向ds18b20中写入数据的函数   */
void ds18b20_write(unsigned char byte)
{
	unsigned char i = 0;
	for (i = 0; i < 8; i++) {
		gpio_set_value(0);
		udelay(2);
		gpio_set_value(1);
		udelay(2);
		gpio_set_value(byte & 0x01);
		udelay(50);
		gpio_set_value(1);
		byte >>= 1;
	}
}

/*   从ds18b20中读取数据的函数   */
unsigned char ds18b20_read(void)
{
	unsigned char i = 0;
	unsigned char byte = 0;
	for (i = 0; i < 8; i++) {
		gpio_set_value(0);
		udelay(2);
		gpio_set_value(1);
		byte >>= 1;
		if(gpio_get_value())
			byte |= 0x80;
		udelay(60);
		gpio_set_value(1);
		udelay(1);
	}
	return byte;
}
/*   读取温度转换结果 */
short read_temp(void)
{
	unsigned char  tmpl = 0, tmph = 0;
	short tmp = 0;
	ds18b20_init();
	
	ds18b20_write(0xcc);
	ds18b20_write(0x44);
	while(!gpio_get_value());
	ds18b20_init();
	ds18b20_write(0xcc);
	ds18b20_write(0xbe);
	tmpl = ds18b20_read();
	tmph = ds18b20_read();
	ds18b20_read();
	tmp = (tmph << 4) | (tmpl >> 4);
	return tmp;
}
