#include "adc.h"
#include "s5p6818_ip_reset.h"

/**********************************************************************
* 函数功能：初始化ADC函数
**********************************************************************/
void hal_adc_init(void)
{
		// 激活ADC控制器
		IP_RESET_REGISTER1 |= (1 << 28);
		// 设置ADC转换的时间
		ADCCON &= (~(0xF << 10));
		// ADC转时钟的个数
		ADCCON = ADCCON & (~(0xF << 6));
		ADCCON = ADCCON | (6 << 6);
		// ADC通道的选择
		ADCCON = ADCCON & (~(0x7 << 3));
		// ADC控制器电源开启
		ADCCON = ADCCON & (~(0x1 << 2));
		// 时钟的分频值
		PRESCALERCON = PRESCALERCON & (~(0x3FF << 0));
		PRESCALERCON = PRESCALERCON | (199 << 0);
		// 分频器的使能
		PRESCALERCON = PRESCALERCON | (1 << 15);
}
/**********************************************************************
* 函数功能：ADC开始转换函数
**********************************************************************/
unsigned int  hal_adc_conversion(void)
{
		unsigned int value = 0;
		// 开启ADC转换
		ADCCON = ADCCON | 1;
		// 等待ADC转换结束
		while(ADCCON & 0x1);
		// 读取ADC转换结果
		value = ADCDAT & 0xFFF;
		// 转换成实际的模拟电压值
		value = 2 * value * 1800 / 4095;

		return value;
}


