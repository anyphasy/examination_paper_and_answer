#include "key_interrupt.h"
void interrupt_gpio_init()
{
	//1. 设置GPIOB8引脚为GPIO功能 ALTFN0[17:16]
	GPIOB.ALTFN0 &= (~(3 << 16));	
	GPIOB.ALTFN1 &= (~(3 << 0));	
	GPIOB.ALTFN1 |= (2 << 0);	
	//2. 设置GPIOB8引脚为输入功能 OUTENB[8]
	GPIOB.OUTENB &= (~(1 << 8));
	GPIOB.OUTENB &= (~(1 << 16));
	//3. 设置GPIOB8引脚的中断触发方式
	//MODEDEX0[17:16] = 0b10  MODEDEXEX[8] = 0b0
	GPIOB.DETMODE0 &= (~(3 << 16));
	GPIOB.DETMODE0 |= (2 << 16);
	GPIOB.DETMODEEX &= (~(1 << 8));
	GPIOB.DETMODE1 &= (~(3 << 0));
	GPIOB.DETMODE1 |= (2 << 0);
	GPIOB.DETMODEEX &= (~(1 << 16));
	
	//4. 设置中断的使能位 INTENB[8]
	GPIOB.INTENB |= (1 << 8);
	GPIOB.INTENB |= (1 << 16);
	//5. 设置中断的检测使能 DETENB[8]
	GPIOB.DETENB |= (1 << 8);
	GPIOB.DETENB |= (1 << 16);
}
void interrupt_gicd_init()
{
	//1. GICD层中断使能寄存器 GICD_ISENABLER2[22]
	GICD_ISENABLER.ISENABLER2 |= (1 << 22);
	//2. 设置中断的优先等级 GICD_IPRIORITYR21[23:16]
	GICD_IPRIORITYR.IPRIORITYR21 &= (~(0xFF << 16));
	GICD_IPRIORITYR.IPRIORITYR21 |= (86 << 16);
	//3. 设置目标分配寄存器，分配给那个CPU
	//GICD_ITARGETSR21[23:16] = 0x1
	GICD_ITARGETSR.ITARGETSR21 &= (~(0xFF << 16));
	GICD_ITARGETSR.ITARGETSR21 |= (1 << 16);
	
	//4.设置GICD层全局使能  GICD_CTRL[0] = 0x1 
	GICD_CTRL |= 1;

}
void interrupt_gicc_init()
{
	//1. 设置中断优先级屏蔽寄存器 GICC_PMR[7:0]
	GICC_PMR |= 255;
	//2. 设置GICC层的中断使能位  GICC_CTRL[0]
	GICC_CTRL |= 1;
}

