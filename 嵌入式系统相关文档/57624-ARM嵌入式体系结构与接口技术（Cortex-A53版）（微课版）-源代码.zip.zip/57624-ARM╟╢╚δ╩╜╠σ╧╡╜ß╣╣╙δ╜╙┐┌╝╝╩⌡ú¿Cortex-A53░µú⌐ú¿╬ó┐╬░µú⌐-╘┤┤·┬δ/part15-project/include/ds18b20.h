#ifndef __DS18B20_H__
#define __DS18B20_H__
#include "s5p6818_alive.h"
/*   ds18b20初始化的函数   */
void ds18b20_init(void);
/*   向ds18b20中写入数据的函数   */
void ds18b20_write(unsigned char);
/*   从ds18b20中读取数据的函数   */
unsigned char ds18b20_read(void);
/*   获取ALIVEGPIO5引脚输入电平   */
int gpio_get_value(void);
/*   设置ALIVEGPIO5引脚输出电平   */
void gpio_set_value(int value);
/*   读取温度转换结果 */
short read_temp(void);

#endif //  __DS18B20_H__
