#ifndef __LED_H__
#define __LED_H__

#include "s5p6818_gpio.h"

typedef enum {
	RED,
	GREEN,
	BLUE,
}led_t;

typedef enum {
	LED_ON,
	LED_OFF,
}stu_t;


void hal_led_init(void);
void led_status(led_t leds, stu_t st);

#endif
