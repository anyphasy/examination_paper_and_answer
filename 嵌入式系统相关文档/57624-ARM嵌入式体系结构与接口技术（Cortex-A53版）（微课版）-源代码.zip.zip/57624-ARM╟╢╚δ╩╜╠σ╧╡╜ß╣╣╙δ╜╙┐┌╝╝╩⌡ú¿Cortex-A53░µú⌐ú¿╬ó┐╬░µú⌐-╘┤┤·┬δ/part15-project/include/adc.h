#ifndef __ADC_H__
#define __ADC_H__
#include "s5p6818_adc.h"


void hal_adc_init(void);
unsigned int  hal_adc_conversion(void);

#endif
