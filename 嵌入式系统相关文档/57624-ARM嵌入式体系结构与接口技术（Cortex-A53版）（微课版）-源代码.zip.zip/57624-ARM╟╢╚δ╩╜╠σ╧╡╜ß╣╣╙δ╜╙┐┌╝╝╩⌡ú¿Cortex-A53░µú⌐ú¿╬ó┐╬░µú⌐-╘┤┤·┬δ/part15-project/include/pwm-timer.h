
#ifndef __PWM_TIMER_H__
#define __PWM_TIMER_H__
#include "s5p6818_pwm.h"
#include "s5p6818_gpio.h"
#include "s5p6818_gic.h"
void hal_timer_init(void);
void hal_timer_on();
void hal_timer_off();
void timer_gicd_init();
void timer_gicc_init();


#endif

