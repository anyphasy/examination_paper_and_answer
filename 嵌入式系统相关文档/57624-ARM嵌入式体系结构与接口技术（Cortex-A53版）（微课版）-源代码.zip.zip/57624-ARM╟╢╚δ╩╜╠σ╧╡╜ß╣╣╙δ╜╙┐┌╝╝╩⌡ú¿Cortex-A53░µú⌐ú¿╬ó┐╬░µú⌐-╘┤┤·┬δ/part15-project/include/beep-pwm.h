
#ifndef __BEEP_PWM_H__
#define __BEEP_PWM_H__
#include "s5p6818_pwm.h"
#include "s5p6818_gpio.h"

void hal_beep_init(void);
void hal_beep_on();
void hal_beep_off();


#endif

