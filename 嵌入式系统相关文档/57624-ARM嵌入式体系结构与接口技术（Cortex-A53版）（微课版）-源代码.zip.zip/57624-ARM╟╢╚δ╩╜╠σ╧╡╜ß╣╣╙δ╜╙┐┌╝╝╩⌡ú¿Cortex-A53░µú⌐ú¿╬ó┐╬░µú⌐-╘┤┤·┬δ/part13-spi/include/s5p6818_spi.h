#ifndef __S5P6818_SPI_H__
#define __S5P6818_SPI_H__
/*
 * *SPI0,1,2 REGISTERS
 * */
typedef struct {
	unsigned int SPI_CONFIGURE ;
	unsigned int RESERVED;
	unsigned int SPI_FIFO_CON ;
	unsigned int SPI_SEL_SIGNAL_CON;
	unsigned int SPI_INT_EN ;
	unsigned int SPI_STATUS;
	unsigned int SPI_TX_DATA;
	unsigned int SPI_RX_DATA;
	unsigned int SPI_PACKET_COUNT ;
	unsigned int SPI_STATUS_PENDING_CLEAR ;
	unsigned int SPI_SWAP_CONFIGURE;
	unsigned int SPI_FEEDBACK_CLOCK_SEL;
}spi_t;
#define  SPI0 (* (volatile spi_t *)0xC005B000 )
#define  SPI1 (* (volatile spi_t *)0xC005C000 )
#define  SPI2 (* (volatile spi_t *)0xC005F000 )

#endif    //__S5P6818_SPI_H__
