#ifndef __SPI_H__
#define __SPI_H__

#include "s5p6818_spi.h"

void slave_enable(void);
void slave_disable(void);
void send_byte(unsigned char data);
unsigned char recv_byte();
void soft_reset(void);
void read_id(void);
void read_byte(void);
void write_byte(void);
void erase_sector(void);

#endif  //__SPI_H__
