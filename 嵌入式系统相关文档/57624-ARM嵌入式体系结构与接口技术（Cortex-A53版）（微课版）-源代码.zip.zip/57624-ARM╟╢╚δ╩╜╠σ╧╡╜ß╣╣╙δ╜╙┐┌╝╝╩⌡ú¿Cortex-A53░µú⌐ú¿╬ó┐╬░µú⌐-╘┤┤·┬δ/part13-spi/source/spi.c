#include "spi.h"
#include "common.h"
void delay(int times)
{
	volatile int i,j;
	for (j = 0; j < times; j++) {
		for (i = 0; i < 500; i++);
	}
}

/*
 *  片选从机
 */
void slave_enable(void)
{
	// 时能片选
	SPI2.SPI_SEL_SIGNAL_CON &= ~0x1; 
	delay(3);
}

/*
 *  取消片选从机
 */
void slave_disable(void)
{
	// 禁止片选
	SPI2.SPI_SEL_SIGNAL_CON |= 0x1; 
	delay(1);
}

/*
 *  功能：向SPI总线发送一个字节
 */
void send_byte(unsigned char data)
{
	// 使能Tx通道
	SPI2.SPI_CONFIGURE |= 0x1; 
	delay(1);
	SPI2.SPI_TX_DATA = data;
	while( !(SPI2.SPI_STATUS & (0x1 << 25)) );
	// 禁止Tx通道
	SPI2.SPI_CONFIGURE &= ~0x1; 
}

/*
 *  功能：从SPI总线读取一个字节
 */
unsigned char recv_byte()
{
	unsigned char data;
	// 使能Rx通道
	SPI2.SPI_CONFIGURE |= 0x1 << 1; 
	delay(1);
	data = SPI2.SPI_RX_DATA;
	delay(1);
	// 禁止Rx通道
	SPI2.SPI_CONFIGURE &= ~(0x1 << 1); 
	return  data;
}

/*
 *  复位spi控制器
 */
void soft_reset(void)
{
	SPI2.SPI_CONFIGURE |= 0x1 << 5;
	delay(1);                     //延时
	SPI2.SPI_CONFIGURE &= ~(0x1 << 5);
}


void read_id(void)
{
	unsigned char ret[4];
	int i;
	soft_reset();
	slave_enable();
	send_byte(0x9f);
	ret[0] = recv_byte();
	ret[1] = recv_byte();
	ret[2] = recv_byte();
	ret[3] = recv_byte();
	slave_disable();
	for(i=0;i<4;i++){
		printf("%#x ", ret[i]);
	}
	printf("\n");
}
/*
 *  读数据
 */
void read_byte(void)
{
	unsigned char ret[5] = {};
	int i;
	soft_reset();
	slave_enable();
	// 读指令
	send_byte(0x03);
	// 24位地址
	send_byte(0x00);
	send_byte(0x00);
	send_byte(0xF0);
	// 读5个字节的数据
	ret[0] = recv_byte();
	ret[1] = recv_byte();
	ret[2] = recv_byte();
	ret[3] = recv_byte();
	ret[4] = recv_byte();
	slave_disable();
	for(i=0;i<5;i++){
		printf("%#x ", ret[i]);
	}
	printf("\n");

}
/*
 * 页编程
 */
void write_byte(void)
{
	soft_reset();
	slave_enable();
	// 写使能
	send_byte(0x06);
	slave_disable();

	soft_reset();
	slave_enable();
	// 发送页编程指令
	send_byte(0x02);
	// 24位地址
	send_byte(0x00);
	send_byte(0x00);
	send_byte(0xF0);
	// 写数据
	send_byte(0x11);
	send_byte(0x22);
	send_byte(0x33);
	send_byte(0x44);
	send_byte(0x55);
	slave_disable();
}


void erase_sector(void)
{
	soft_reset();
	slave_enable();
	send_byte(0x06);
	slave_disable();

	soft_reset();
	slave_enable();
	send_byte(0xD8);
	send_byte(0x00);
	send_byte(0x00);
	send_byte(0xF0);
	slave_disable();

}


			
