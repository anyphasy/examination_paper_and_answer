
#include "spi.h"
#include "s5p6818_gpio.h"
#include "s5p6818_ip_reset.h"
#include "common.h"
#include "delay.h"

/**********************
* 主函数：main函数
 **********************/
int main(void)
{

	IP_RESET_REGISTER1 &= (~(0x3F << 12));
	// SPI控制器始终源配置
	unsigned int *addr = (unsigned int *)0xC00A7000;	
	*addr = 0x4;
	*(addr + 1) = 0x328;
	IP_RESET_REGISTER1 |= (0x3F << 12);

	// spi2 GPIO 复用功能配置
	GPIOC.ALTFN0 = (GPIOC.ALTFN0 & (~(0x3 << 18))) | (2 << 18);
	GPIOC.ALTFN0 = (GPIOC.ALTFN0 & (~(0x3<< 20))) | (2 << 20);
	GPIOC.ALTFN0 = (GPIOC.ALTFN0 & (~(0x3 << 22))) | (2 << 22);
	GPIOC.ALTFN0 = (GPIOC.ALTFN0 & (~(0x3 << 24))) | (2 << 24);

	/*spi总线时钟配置*/
	// 软复位SPI控制器
	soft_reset();	      
	// 主机模式, CPOL = 0, CPHA = 0 (Format A)
	SPI2.SPI_CONFIGURE &= ~( (0x1 << 4) | (0x1 << 3) | (0x1 << 2) | 0x3);
	// BUS_WIDTH=8bit,CH_WIDTH=8bit
	SPI2.SPI_FIFO_CON &= ~((0x3 << 17) | (0x3 << 29));  
	// 选择自动选择芯片
	SPI2.SPI_SEL_SIGNAL_CON &= (~(0x1 << 1));        
	delay_ms(10);    //延时

    printf("******SPI FLASH test!******\n");
	
	// 读M25P32芯片的ID号
	read_id();
	write_byte();
    while(1)
    {		
		read_byte();
		delay_ms(1000);
    } 

	return 0;
} 

