#include "wdt.h"
void WDT_Init(void)
{
		// 激活APB总线
		IP_RESET_REGISTER1 |= (1 << 26);
		// 设置一级预分频值   进行（249 + 1）分频
		WTCON = WTCON & (~(0xFF << 8));
		WTCON = WTCON | (249 << 8);
		// 设置二级预分频值  进行64分频
		WTCON = WTCON & (~(0x3 << 3));
		WTCON = WTCON | (0x2 << 3);
		// WTDAT = 0x3FFF;
		// 赋初始值
		WTCNT = 9375 * 5;
		// 使能看门狗复位信号产生器
		WTCON = WTCON | ((0x1 << 2));
		// 使能看门狗定时器
		WTCON = WTCON | (0x1 << 5);
}
