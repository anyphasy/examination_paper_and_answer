#include "wdt.h"

int main()
{
		WDT_Init();
		while(1)
		{
			// 喂狗和不喂狗
			// WTCNT = 9375 * 5;
		}
		return 0;
}
