#ifndef __S5P6818_WDT_H__
#define __S5P6818_WDT_H__
/********************************
* WDT寄存器封装
*********************************/
#define     WTCON 			(*(volatile unsigned int *)0xC0019000)
#define  	WTDAT			(*(volatile unsigned int *)0xC0019004)
#define 	WTCNT			(*(volatile unsigned int *)0xC0019008)
#define 	WTCLRINT		(*(volatile unsigned int *)0xC001900C)

#endif
