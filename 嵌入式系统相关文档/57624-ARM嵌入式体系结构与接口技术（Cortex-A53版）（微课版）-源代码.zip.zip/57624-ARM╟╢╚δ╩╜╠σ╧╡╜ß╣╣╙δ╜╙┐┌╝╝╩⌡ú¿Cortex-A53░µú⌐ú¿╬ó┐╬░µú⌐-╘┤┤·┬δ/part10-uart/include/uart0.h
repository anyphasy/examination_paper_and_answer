#ifndef __UART0_H__
#define __UART0_H__

#include "s5p6818_uart.h"
#include "s5p6818_gpio.h"

void hal_uart_init(void);
void uart_send(char ch);
char uart_recv(void);
void uart_send_str(char *str);

#endif
