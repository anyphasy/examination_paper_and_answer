#include "uart0.h"

/*********************************
* 主函数：main函数
*********************************/
int main()
{
	hal_uart_init();    // 串口初始化
	uart_send_str("/******UART0 TEST!******/\n");  // 发送字符串到串口工具上
	while(1)
	{
		uart_send(uart_recv());     // 接收字符并发送字符
	}
	return 0;
}
