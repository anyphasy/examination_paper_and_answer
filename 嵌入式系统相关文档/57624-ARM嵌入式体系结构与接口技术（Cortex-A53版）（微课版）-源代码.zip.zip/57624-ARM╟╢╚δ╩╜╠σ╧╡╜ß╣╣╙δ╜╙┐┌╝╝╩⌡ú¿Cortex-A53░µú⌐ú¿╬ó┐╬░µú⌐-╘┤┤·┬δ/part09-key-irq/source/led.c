#include "s5p6818_gpio.h"
/*********************************
* 函数功能：led灯初始化
*********************************/

void hal_led_init(void)
{
	// RED
	GPIOA.ALTFN1 = GPIOA.ALTFN1 & (~(0x3 << 24));
	GPIOA.OUTENB = GPIOA.OUTENB | (1 << 28);
	
	// GREEN
	GPIOE.ALTFN0 = GPIOE.ALTFN0 & (~(0x3<< 26));
	GPIOE.OUTENB = GPIOE.OUTENB | (1 << 13);

	//BLUE
	GPIOB.ALTFN0 = (GPIOB.ALTFN0 & (~(0x3 << 24))) | (0x2 << 24);
	GPIOB.OUTENB |= (1 << 12);
}
