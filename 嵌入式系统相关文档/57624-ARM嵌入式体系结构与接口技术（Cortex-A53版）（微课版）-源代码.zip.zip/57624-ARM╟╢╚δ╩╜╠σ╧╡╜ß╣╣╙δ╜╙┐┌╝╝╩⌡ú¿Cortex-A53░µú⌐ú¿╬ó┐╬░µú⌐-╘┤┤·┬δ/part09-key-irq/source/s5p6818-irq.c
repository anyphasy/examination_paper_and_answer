/*
 * s5p6818-irq.c
 *

 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include "s5p6818-irq.h"
#include "s5p6818_gpio.h"
#include "s5p6818_gic.h"
#include "common.h"
static struct irq_handler_t s5p6818_irq_handler[32 + 64];
static struct irq_handler_t s5p6818_irq_handler_gpioa[32];
static struct irq_handler_t s5p6818_irq_handler_gpiob[32];
static struct irq_handler_t s5p6818_irq_handler_gpioc[32];
static struct irq_handler_t s5p6818_irq_handler_gpiod[32];
static struct irq_handler_t s5p6818_irq_handler_gpioe[32];
static struct irq_handler_t s5p6818_irq_handler_gpioalv[6];

static void s5p6818_irq_handler_func_gpioa(void * data)
{
}

static void s5p6818_irq_handler_func_gpiob(void * data)
{
}

static void s5p6818_irq_handler_func_gpioc(void * data)
{
}

static void s5p6818_irq_handler_func_gpiod(void * data)
{
}

static void s5p6818_irq_handler_func_gpioe(void * data)
{
}

static inline void s5p6818_gpio_alv_write_enable(void)
{
}

static inline void s5p6818_gpio_alv_write_disable(void)
{
}

static void s5p6818_irq_handler_func_gpioalv(void * data)
{

}

void el1_sync_invalid(void)
{
}

void el1_irq_invalid(void)
{
}

void el1_fiq_invalid(void)
{
}

void el1_error_invalid(void)
{
}

void el1_sync(void)
{
}

void el1_irq(void)
{
	unsigned int irq_num;
	//获取中断号
	irq_num = GICC_IAR & 0x3FF;
	switch(irq_num){
		case 86:
			if((GPIOB.DET & (1 << 8)) == (1 << 8))
			{
				// led灯交替闪烁
				GPIOA.OUT ^= (1 << 28);
				printf("VOL+ KEY!\n");
				//6. 清除GPIO中断挂起标志位 DET[8]
				GPIOB.DET |= (1 << 8);
			}
			else if((GPIOB.DET & (1 << 16)) == (1 << 16))
			{
				// led灯交替闪烁
				GPIOE.OUT ^= (1 << 13);
				//6. 清除GPIO中断挂起标志位 DET[16]
				GPIOB.DET |= (1 << 16);
			
			}
			// 5. 清除分配器层中断挂起标志位 GICD_ICPENDER2[22]
			GICD_ICPENDER.ICPENDER2 |= (1 << 22);
			break;
		case 87:
			break;
		default:
			break;
	}
	// 清除中断号 
	GICC_EOIR = (GICC_EOIR & (~0x3FF)) | irq_num;
}

void el0_sync(void)
{
}

void el0_irq(void)
{
}

void el0_fiq_invalid(void)
{
}

void el0_error_invalid(void)
{
}

void el0_sync_compat(void)
{
}

void el0_irq_compat(void)
{
}

void el0_fiq_invalid_compat(void)
{
}

void el0_error_invalid_compat(void)
{
}
#define 	GPIOBDET			0xC001B014
/*
 * do_irq handles the Irq exception.
 */

void s5p6818_irq_enable(int no)
{
}

void s5p6818_irq_disable(int no)
{
}

void s5p6818_irq_set_type(int no, enum irq_type_t type)
{
}


