#include "key_interrupt.h"
#include "led.h"

void delay_ms(unsigned int ms)
{
	unsigned int i,j;
	for(i = 0; i < ms; i++)
		for(j = 0; j < 1800; j++);
}
int main()
{
	hal_led_init();
	interrupt_gpio_init();
	interrupt_gicd_init();
	interrupt_gicc_init();

	printf("/******key interrupt test!******/\n");
	while(1)
	{
	}
	return 0;
}

