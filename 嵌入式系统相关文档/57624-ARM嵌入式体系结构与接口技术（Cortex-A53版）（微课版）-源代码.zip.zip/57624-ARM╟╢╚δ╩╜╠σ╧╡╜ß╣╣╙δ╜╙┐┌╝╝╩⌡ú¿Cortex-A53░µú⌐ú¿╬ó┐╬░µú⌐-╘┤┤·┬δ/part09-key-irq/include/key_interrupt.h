#ifndef __KEY_INTERRUPT_H__
#define __KEY_INTERRUPT_H__

#include "s5p6818_gic.h"
#include "s5p6818_gpio.h"

void interrupt_gpio_init();
void interrupt_gicd_init();
void interrupt_gicc_init();

#endif
