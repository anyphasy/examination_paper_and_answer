#ifndef __LED_H__
#define __LED_H__

#include "s5p6818_gpio.h"

void hal_led_init(void);

#endif
