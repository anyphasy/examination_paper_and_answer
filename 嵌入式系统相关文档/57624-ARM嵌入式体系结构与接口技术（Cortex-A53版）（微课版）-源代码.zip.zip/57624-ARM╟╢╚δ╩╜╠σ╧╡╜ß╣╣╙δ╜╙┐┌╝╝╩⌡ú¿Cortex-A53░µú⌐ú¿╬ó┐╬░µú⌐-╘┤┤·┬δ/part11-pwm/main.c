#include "pwm.h"

int main()
{
		PWM_Init();
		while(1)
		{
		}
		return 0;
}
