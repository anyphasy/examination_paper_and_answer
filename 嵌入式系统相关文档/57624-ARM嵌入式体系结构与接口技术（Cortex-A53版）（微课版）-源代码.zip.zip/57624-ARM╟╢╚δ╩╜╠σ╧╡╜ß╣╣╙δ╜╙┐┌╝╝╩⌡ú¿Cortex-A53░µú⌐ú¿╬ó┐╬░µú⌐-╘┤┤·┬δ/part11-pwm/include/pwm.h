#ifndef __PWM_H__
#define __PWM_H__

#include "s5p6818_pwm.h"
#include "s5p6818_gpio.h"
void PWM_Init(void);

#endif
