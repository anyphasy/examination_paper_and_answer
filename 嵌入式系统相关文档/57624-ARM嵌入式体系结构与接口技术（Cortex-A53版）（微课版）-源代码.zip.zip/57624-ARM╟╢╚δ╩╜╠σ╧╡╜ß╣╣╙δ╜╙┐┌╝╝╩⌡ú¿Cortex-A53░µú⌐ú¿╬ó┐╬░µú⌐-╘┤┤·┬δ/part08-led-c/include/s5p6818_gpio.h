#ifndef __S5P6818_GPIO_H__
#define __S5P6818_GPIO_H__
#include "common.h"
/************* GPIOA register**************/
typedef struct{
	uint32 OUT;
	uint32 OUTENB;
	uint32 DETMODE0;
	uint32 DETMODE1;
	uint32 INTENB;
	uint32 DET;
	uint32 PAD;
	uint32 Reserved1;
	uint32 ALTFN0;
	uint32 ALTFN1;
	uint32 DETMODEEX;
	uint32 Reserved2;
	uint32 Reserved3;
	uint32 Reserved4;
	uint32 Reserved5;
	uint32 DETENB;
	uint32 SLEW;
	uint32 SLEW_DISABLE_DEFAULT;
	uint32 DRV1;
	uint32 DRV1_DISABLE_DEFAULT;
	uint32 DRV0;
	uint32 DRV0_DISABLE_DEFAULT;
	uint32 PULLSEL;
	uint32 PULLSEL_DISABLE_DEFAULT;
	uint32 PULLENB;
	uint32 PULLENBD_DISABLE_DEFAULT;
} gpio;

#define  GPIOA     (* (volatile gpio *)0xC001A000)
#define  GPIOB     (* (volatile gpio *)0xC001B000)
#define  GPIOC     (* (volatile gpio *)0xC001C000)
#define  GPIOD     (* (volatile gpio *)0xC001D000)
#define  GPIOE     (* (volatile gpio *)0xC001E000)

#endif
