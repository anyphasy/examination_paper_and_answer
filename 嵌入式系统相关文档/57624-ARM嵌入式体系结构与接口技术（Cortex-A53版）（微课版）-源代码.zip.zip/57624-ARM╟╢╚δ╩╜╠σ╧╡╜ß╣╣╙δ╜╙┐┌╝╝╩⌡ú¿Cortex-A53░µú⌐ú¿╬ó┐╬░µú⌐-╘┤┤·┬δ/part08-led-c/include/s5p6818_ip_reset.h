#ifndef __S5P6818_IP_RESET_H__
#define __S5P6818_IP_RESET_H__

#define  IP_RESET_REGISTER0       (*(volatile unsigned int *)0xC0012000)
#define  IP_RESET_REGISTER1       (*(volatile unsigned int *)0xC0012004)
#define  IP_RESET_REGISTER2       (*(volatile unsigned int *)0xC0012008)

#endif
