#ifndef __S5P6818_IRQ_H__
#define __S5P6818_IRQ_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "cp15.h"
#include "reg-gpio.h"
#include "reg-alv.h"
#include "reg-gic.h"
#include "interrupt.h"

struct pt_regs {
	unsigned long elr;
	unsigned long regs[31];
};

void s5p6818_irq_set_type(int no, enum irq_type_t type);
void s5p6818_irq_disable(int no);
void s5p6818_irq_enable(int no);
void s5p6818_irq_init(void);
void s5p6818_irq_exit(void);

#ifdef __cplusplus
}
#endif

#endif /* __S5P6818_IRQ_H__ */
