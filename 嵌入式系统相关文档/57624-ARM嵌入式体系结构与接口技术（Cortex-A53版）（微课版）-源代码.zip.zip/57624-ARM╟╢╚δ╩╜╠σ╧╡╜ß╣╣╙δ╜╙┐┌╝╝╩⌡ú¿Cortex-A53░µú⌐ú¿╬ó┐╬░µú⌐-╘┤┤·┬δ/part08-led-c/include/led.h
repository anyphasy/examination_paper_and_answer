#ifndef __LED_H__
#define __LED_H__
/********************************
* 寄存器封装
*********************************/
#define   GPIOAOUT         (*(volatile unsigned int *)0xC001A000)
#define   GPIOAOUTENB     (*(volatile unsigned int *)0xC001A004)
#define   GPIOAALTFN1      (*(volatile unsigned int *)0xC001A024)

void hal_led_init(void);
void hal_led_flash(void);

#endif
