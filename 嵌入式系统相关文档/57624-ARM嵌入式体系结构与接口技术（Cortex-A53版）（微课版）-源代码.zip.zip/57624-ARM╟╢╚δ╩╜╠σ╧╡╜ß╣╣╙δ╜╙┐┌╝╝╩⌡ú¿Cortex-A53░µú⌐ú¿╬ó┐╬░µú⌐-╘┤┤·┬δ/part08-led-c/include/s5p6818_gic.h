#ifndef __S5P6818_GIC_H__
#define __S5P6818_GIC_H__

#include "common.h"



// distributor Control Regist
#define 	GICD_CTRL		 (*(volatile unsigned int*)0xC0009000)	

// Interrupt Set-Enable Register 0x0000_0000
typedef struct {
	uint32	ISENABLER0;
	uint32	ISENABLER1;
	uint32	ISENABLER2;
	uint32	ISENABLER3;
	uint32	ISENABLER4;
}gicd_isenabler;
#define  GICD_ISENABLER    (*(volatile gicd_isenabler *)0xC0009100)

// Interrupt Clear-Pending Register
typedef struct {
	uint32	ICPENDER0;
	uint32	ICPENDER1;
	uint32	ICPENDER2;
	uint32	ICPENDER3;
	uint32	ICPENDER4;
}gicd_icpender;
#define  GICD_ICPENDER    (*(volatile gicd_icpender *)0xC0009280)

// Interrupt Priority Register
typedef struct {
	uint32	IPRIORITYR0;   	//A:0-3
	uint32	IPRIORITYR1;	//A:4-7
	uint32	IPRIORITYR2;	//A:8-11
	uint32	IPRIORITYR3;	//A:12-15
	uint32	IPRIORITYR4;	//A:16-19
	uint32	IPRIORITYR5;	//A:20-23
	uint32	IPRIORITYR6;	//A:24-27
	uint32	IPRIORITYR7;	//A:28-31
	uint32	IPRIORITYR8;	//B:0-3
	uint32	IPRIORITYR9;	//B:4-7
	uint32	IPRIORITYR10;	//B:8-11
	uint32	IPRIORITYR11;	//B:12-15
	uint32	IPRIORITYR12;	//B:16-19
	uint32	IPRIORITYR13;	//B:20-23
	uint32	IPRIORITYR14;	//B:24-27
	uint32	IPRIORITYR15;	//B:28-31
	uint32	IPRIORITYR16;	//C:0-3
	uint32	IPRIORITYR17;	//C:4-7
	uint32	IPRIORITYR18;	//C:8-11
	uint32	IPRIORITYR19;	//C:12-15
	uint32	IPRIORITYR20;	//C:16-19
	uint32	IPRIORITYR21;	//C:20-23
	uint32	IPRIORITYR22;	//C:24-27
	uint32	IPRIORITYR23;	//C:28-31
	uint32	IPRIORITYR24;	//D:0-3
	uint32	IPRIORITYR25;	//D:4-7
	uint32	IPRIORITYR26;	//D:8-11
	uint32	IPRIORITYR27;	//D:12-15
	uint32	IPRIORITYR28;	//D:16-19
	uint32	IPRIORITYR29;	//D:20-23
	uint32	IPRIORITYR30;	//D:24-27
	uint32	IPRIORITYR31;	//D:28-31
	uint32	IPRIORITYR32;	//E:0-3
	uint32	IPRIORITYR33;	//E:4-7
	uint32	IPRIORITYR34;	//E:8-11
	uint32	IPRIORITYR35;	//E:12-15
	uint32	IPRIORITYR36;	//E:16-19
	uint32	IPRIORITYR37;	//E:20-23
	uint32	IPRIORITYR38;	//E:24-27
	uint32	IPRIORITYR39;	//E:28-31
}gicd_iprioriryr;
#define  GICD_IPRIORITYR    (*(volatile gicd_iprioriryr *)0xC0009400)

// Interrupt Processor Target Register 
typedef struct {
	uint32	ITARGETSR0;
	uint32	ITARGETSR1;
	uint32	ITARGETSR2;
	uint32	ITARGETSR3;
	uint32	ITARGETSR4;
	uint32	ITARGETSR5;
	uint32	ITARGETSR6;
	uint32	ITARGETSR7;
	uint32	ITARGETSR8;
	uint32	ITARGETSR9;
	uint32	ITARGETSR10;
	uint32	ITARGETSR11;
	uint32	ITARGETSR12;
	uint32	ITARGETSR13;
	uint32	ITARGETSR14;
	uint32	ITARGETSR15;
	uint32	ITARGETSR16;
	uint32	ITARGETSR17;
	uint32	ITARGETSR18;
	uint32	ITARGETSR19;
	uint32	ITARGETSR20;
	uint32	ITARGETSR21;
	uint32	ITARGETSR22;
	uint32	ITARGETSR23;
	uint32	ITARGETSR24;
	uint32	ITARGETSR25;
	uint32	ITARGETSR26;
	uint32	ITARGETSR27;
	uint32	ITARGETSR28;
	uint32	ITARGETSR29;
	uint32	ITARGETSR30;
	uint32	ITARGETSR31;
	uint32	ITARGETSR32;
	uint32	ITARGETSR33;
	uint32	ITARGETSR34;
	uint32	ITARGETSR35;
	uint32	ITARGETSR36;
	uint32	ITARGETSR37;
	uint32	ITARGETSR38;
	uint32	ITARGETSR39;
}gicd_itargetsr;

#define  GICD_ITARGETSR   (*(volatile gicd_itargetsr *)0xC0009800)
#define  GICC_CTRL 	(*(volatile unsigned int*)0xC000A000)	// CPU Interface Control Register	
#define  GICC_PMR 	(*(volatile unsigned int*)0xC000A004)		// Interrupt Priority Mask Register 		
#define  GICC_IAR 	(*(volatile unsigned int*)0xC000A00C)		// Interrupt Acknowledge Register 		#define  GICC_EOIR 	(*(volatile unsigned int*)0xC000A010)		// End of Interrupt Register 		
#define  GICC_EOIR  (*(volatile unsigned int*)0xC000A010)		// End of Interrupt Register 


#endif
