#include "led.h"

void delay_ms(unsigned int ms);
/*********************************
* 函数功能：led灯初始化
*********************************/
void hal_led_init(void)
{
		GPIOAALTFN1 = GPIOAALTFN1 & (~(0x3 << 24));   // 设置GPIOA28为GPIO功能
		GPIOAOUTENB = GPIOAOUTENB | (1 << 28);       // 设置GPIOA28为输出功能
}

/*********************************
* 函数功能：led闪烁
*********************************/
void hal_led_flash(void)
{
		GPIOAOUT = GPIOAOUT | (1 << 28);       // 点亮LED灯
		delay_ms(500);                                // 延时500ms
		GPIOAOUT = GPIOAOUT & (~(1 << 28));   // 熄灭LED灯
		delay_ms(500);                                // 延时500ms
}

