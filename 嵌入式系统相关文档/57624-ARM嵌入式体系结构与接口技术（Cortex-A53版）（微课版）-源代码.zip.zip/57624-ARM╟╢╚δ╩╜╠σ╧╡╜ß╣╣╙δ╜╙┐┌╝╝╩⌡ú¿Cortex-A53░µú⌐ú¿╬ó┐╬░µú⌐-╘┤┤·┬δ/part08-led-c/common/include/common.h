#ifndef __COMMON_H__
#define __COMMOM_H__

#define  	__REG(x)					(*(volatile unsigned int *)(x))  
#define    uint32                       unsigned int
void printf (const char *fmt, ...);

#endif
