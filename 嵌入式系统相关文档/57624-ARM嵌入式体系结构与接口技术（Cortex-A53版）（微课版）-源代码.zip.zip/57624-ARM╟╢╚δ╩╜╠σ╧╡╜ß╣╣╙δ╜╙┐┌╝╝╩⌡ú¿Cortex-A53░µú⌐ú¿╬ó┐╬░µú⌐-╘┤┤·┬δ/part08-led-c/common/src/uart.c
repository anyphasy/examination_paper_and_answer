#include "s5p6818_uart.h"
#include "s5p6818_gpio.h"
/*******************************
* 函数功能：串口初始化
********************************/
void hal_uart_init(void)
{
		// 1. 设置GPIOD14和18为串口功能
		GPIOD.ALTFN0 = GPIOD.ALTFN0 & (~(0x3 << 28));
		GPIOD.ALTFN0 = GPIOD.ALTFN0 | (0x1 << 28);
		GPIOD.ALTFN1 = GPIOD.ALTFN1 & (~( 0x3 << 4));
		GPIOD.ALTFN1 = GPIOD.ALTFN1 | (0x1 << 4);
		// 2. 设置数据帧的格式，正常模式，八位数据位，一位停止位，无奇偶校验位
		UART0.ULCON = UART0.ULCON & (~(0x1 << 6));
		UART0.ULCON = UART0.ULCON & (~(0x7 << 3));
		UART0.ULCON = UART0.ULCON & (~(0x1 << 2));
		UART0.ULCON = UART0.ULCON | (0x3 << 0);
		// 3. 设置串口的波特率为115200
		UART0.UBRDIV = 26;
		UART0.UFRACVAL = 2;
		// 4. 设置串口为轮训模式
		UART0.UCON = UART0.UCON & (~(0xF << 0));
		UART0.UCON = UART0.UCON | (0x5 << 0);
}
/*******************************
* 函数功能：串口输出一个字符
  * 函数参数：ch：S5P6818通过串口发送一个字符到串口工具
********************************/
void putc(char ch)
{
		while(!(UART0.UTRSTAT & (0x1 << 1)));
		UART0.UTXH = ch;
		if(ch == '\n')
			putc('\r');
}
/*******************************
* 函数功能：串口接收一个字符
  * 函数返回值：char：S5P6818串口从电脑串口工具收到字符
********************************/
char getc(void)
{
		char ch;
		while(!(UART0.UTRSTAT & (0x1 << 0)));
		ch = UART0.URXH;
		return ch;
}
/*******************************
* 函数功能：串口输出一个字符串
  * 函数参数：ch：S5P6818通过串口发送一个字符串到串口工具
********************************/
void puts(char *str)
{
		while(*str != '\0')
			putc(*str++);
}

