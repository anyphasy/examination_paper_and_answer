#include "led.h"

/*********************************
* 函数功能：延时函数
* 函数参数：延时时间，单位毫秒
*********************************/
void delay_ms(unsigned int ms)
{
		unsigned int i,j;
		for(i = 0; i < ms; i++)
			for(j = 0; j < 1800; j++);
}
/*********************************
* 主函数：main函数
*********************************/
int main()
{
		hal_led_init();     // led灯初始化
		while(1)
		{
			hal_led_flash();    // led灯闪烁
		}
		return 0;
}

